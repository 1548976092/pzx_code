#gcc bmp280.c  -std=c99 -o bmp280


gcc bmp280.c  -std=gnu99 -o bmp280

