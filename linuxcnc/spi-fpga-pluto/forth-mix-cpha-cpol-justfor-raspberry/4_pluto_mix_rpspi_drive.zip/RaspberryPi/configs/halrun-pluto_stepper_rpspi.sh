#!/bin/sh

halrun -I -f pluto_stepper_rpspi_test3.hal
