                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1592092
NanoPi M1’s 3D Printed Housing by FriendlyARM3DPrinter is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

NanoPi M1’s 3D Printed Housing;
Customized Jacket, Cute and Firm;
3D Printing Files Available for free download.
Easy to Assemble, Firm and Flexible;
It has appropriate room and openings for ports and interfaces, and dedicated design for heat sink.

# Print Settings

Printer Brand: MakerBot
Printer: MakerBot Replicator 2X
Rafts: Doesn't Matter
Supports: Doesn't Matter

# Post-Printing

![Alt text](https://cdn.thingiverse.com/assets/12/7b/cb/68/15/M1_housing_en_01.jpg)

![Alt text](https://cdn.thingiverse.com/assets/5c/07/10/17/df/DSC_9942.jpg)

![Alt text](https://cdn.thingiverse.com/assets/d4/27/68/82/a2/DSC_0246.jpg)

# How I Designed This

![Alt text](https://cdn.thingiverse.com/assets/1c/e4/43/a6/27/DSC_0242.jpg)

![Alt text](https://cdn.thingiverse.com/assets/24/af/94/d0/12/M1_housing_en_06.jpg)

![Alt text](https://cdn.thingiverse.com/assets/1b/cc/8f/ba/73/DSC_9965.jpg)

![Alt text](https://cdn.thingiverse.com/assets/ed/c7/1a/19/67/M1_housing_en_09.jpg)

![Alt text](https://cdn.thingiverse.com/assets/02/b0/fd/8d/10/M1_housing_en_08.jpg)

![Alt text](https://cdn.thingiverse.com/assets/08/df/7c/69/bf/M1_housing_en_10.jpg)

## Screw Set

1.Short Screws: M3 x 5(mm)
2.Long Screws: M3 x 10(mm) 
3.Pillars: M3 x 11(mm)

# Custom Section

## NanoPi M1’s 3D Printed Housing

Customized Jacket, Cute and Firm ,3D Printing Files Available for free download.
And you can find more information through this site:http://www.friendlyarm.com/index.php?route=product/product&product_id=110
About US:http://www.friendlyarm.com/index.php?route=common/home