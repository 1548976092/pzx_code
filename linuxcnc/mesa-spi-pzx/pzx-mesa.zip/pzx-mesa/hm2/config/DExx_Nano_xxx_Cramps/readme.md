Shared configs for the DE0_Nano_SoC_Cramps and DE10_Nano_FB_Cramps projects
The DExx ..._Cramps projects are minimalistic as only the hm2 cores in current configs are included.

A new config is added by creating and then editing a new copy of these 2 files.

    PIN_(your-custom-name).vhd
    atlas_(your-custom-name).sv

If you wish to create a new config including a not yet (in current configs) included core,
post a DExx_.._Cramps new core feature request. (in the GGroup).
